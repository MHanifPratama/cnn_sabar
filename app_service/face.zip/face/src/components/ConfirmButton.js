import './ConfirmButton.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const ConfirmButton = ({ onClick, predictedNpm }) => {
  return (
    <div>
      <div className='row r'>
        <div>
          <button className='cn'>{predictedNpm}</button>
        </div>
      </div>

      <div className='row r'>
        <div>
          <button className='cn'>Mahasiswa</button>
        </div>
      </div>

      <div className='row r'>
        <div className='container'>
          <button className='Benar'>Benar</button>
          <button className='Salah' onClick={onClick}>Salah</button>
        </div>
      </div>
    </div>
  )
}

export default ConfirmButton;
