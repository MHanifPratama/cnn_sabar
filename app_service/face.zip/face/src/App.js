import './App.css';
import React, {useState} from 'react';
import ConfirmButton from './components/ConfirmButton';
import CustomWebcam from './components/CustomWebCam';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  const [showCapture, setShowCapture] = useState(true);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleCapture = () => {
    setShowCapture(false);
    setShowConfirm(true);
  };

  const handleRetake = () => {
    setShowCapture(true);
    setShowConfirm(false);
  };
  
  return (
    <div className="App overflow-hidden">

      <div className='row'>

        <div className='col'>
          <br/>
          {showCapture ? (<CustomWebcam onCapture={handleCapture} onRetake={handleRetake} />) : null}
          {showConfirm ? <ConfirmButton onRetake={handleRetake} /> : null}
        </div>

        <div className='col'>
          <h1>waw</h1>
        </div>

      </div>

    </div>
  );
}

export default App;
